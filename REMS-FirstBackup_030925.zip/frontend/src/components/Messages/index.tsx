"use client";

// Path: /frontend/src/components/Messages/index.tsx
import { ConversationList } from "./ConversationList";
import { MessageThread } from "./MessageThread";

export { ConversationList, MessageThread };
